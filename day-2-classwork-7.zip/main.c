/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {
    int arr[]={2,5,6,7,8,9,69,12}; 
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }
    max1 = arr[0];
    max2 = arr[1];
    for (i = 1; i < 10; i++) {
        if (arr[i] > max1) {
            max2 = max1;
            max1 = arr[i];
        }
        else if (arr[i] > max2) {
            max2 = arr[i];
        }
    }
    printf("The two largest numbers are %d and %d\n", max1, max2);
    
    return 0;
}

