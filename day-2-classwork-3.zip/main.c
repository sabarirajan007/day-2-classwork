#include<stdio.h>
int  main( )
{
int n;
printf(" Enter the Numbers of Array Element: ") ;
scanf("%d ",&n) ;

int arr[n];
printf("\n Enter the Array Element : \n") ;

for ( int i = 0 ; i < n ; i++)
{
scanf("%d ",& arr[i]) ;
}
printf("\n Array Elements are : \n ") ;
for (int i = 0 ; i <  n ; i++)
{
printf("\t %d ",arr[i]) ;
}
return 0;
}