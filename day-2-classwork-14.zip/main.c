#include <stdio.h>

int sum_of_natural_numbers(int n) {
    if (n == 0) {
        return 0;
    } else {
        return n + sum_of_natural_numbers(n - 1);
    }
}

int main() {
    int num;
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    printf("The sum of the first %d natural numbers is %d", num, sum_of_natural_numbers(num));
    return 0;
}

