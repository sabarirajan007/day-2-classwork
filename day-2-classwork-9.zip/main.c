#include <stdio.h>

int main() {
    int num, largest1, largest2;

    int a[]={6,3,88,2,67};

   
    scanf("%d", &num);

  
    if (num >= 0) {
        largest1 = num;
        largest2 = -1;
    } else {
        largest1 = largest2 = -1;
    }

    
    while (num >= 0) {
        if (num > largest1) {
            largest2 = largest1;
            largest1 = num;
        } else if (num > largest2) {
            largest2 = num;
        }

        scanf("%d", &num);
    }

    
    if (largest2 >= 0) {
        printf("The first largest number is %d\n", largest1);
        printf("The second largest number is %d\n", largest2);
    } else {
        printf("There are not enough positive numbers.\n");
    }

    return 0;
}